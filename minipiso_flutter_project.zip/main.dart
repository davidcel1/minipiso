// Main entry point of the app
void main() => runApp(MinipisoApp());